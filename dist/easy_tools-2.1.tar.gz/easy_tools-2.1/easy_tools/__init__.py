from easy_tools.triplet_sum_occurrence import triplet_occurrence
from easy_tools.doublet_sum_occurrence import doublet_occurrence
from easy_tools.equilibrium_point import equilibrium_point
from easy_tools.non_divisible_subset_length import non_divisible_subset_len

name = 'easy_tools'
