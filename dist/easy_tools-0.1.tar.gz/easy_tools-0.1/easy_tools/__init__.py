from easy_tools.triplet_sum_occurrence import triplet_sum_occurrence
from easy_tools.doublet_sum_occurrence import doublet_sum_occurrence

name = 'easy_tools'
