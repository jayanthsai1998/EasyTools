esay_tools package provides coders to keep many python functions handy.

By using these functions which are written at optimized level,
python becomes much more speeder( since we know that python works faster with functions ).