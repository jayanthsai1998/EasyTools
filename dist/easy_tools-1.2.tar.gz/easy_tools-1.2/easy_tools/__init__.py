from easy_tools.triplet_sum_occurrence import triplet_occurrence
from easy_tools.doublet_sum_occurrence import doublet_occurrence
from easy_tools.equilibrium_point import equilibrium_point

name = 'easy_tools'
