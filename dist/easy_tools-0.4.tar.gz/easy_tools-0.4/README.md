Open source contribution for Python functions
