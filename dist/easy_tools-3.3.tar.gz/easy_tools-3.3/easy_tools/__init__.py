from easy_tools.triplet_sum_occurrence import triplet_occurrence
from easy_tools.doublet_sum_occurrence import doublet_occurrence
from easy_tools.equilibrium_point import equilibrium_point
from easy_tools.non_divisible_subset_length import non_divisible_subset_len
from easy_tools.left_leaders import leaders_to_left
from easy_tools.right_leaders import leaders_to_right
from easy_tools.largest_number import largest_number


name = 'easy_tools'
