Python's itertools library is a gem - you can compose elegant solutions for a variety of problems with the functions it provides.
In easy-tools we collect additional building blocks, recipes, and routines for working with Python iterables.

easy-tools package comes with many python functions handy.
